require 'test_helper'

class DistritoOrigenTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
