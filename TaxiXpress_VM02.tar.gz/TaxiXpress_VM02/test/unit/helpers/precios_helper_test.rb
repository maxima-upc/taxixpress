require 'test_helper'

class PreciosHelperTest < ActionView::TestCase
end
