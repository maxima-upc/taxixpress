require 'test_helper'

class ClientesHelperTest < ActionView::TestCase
end
