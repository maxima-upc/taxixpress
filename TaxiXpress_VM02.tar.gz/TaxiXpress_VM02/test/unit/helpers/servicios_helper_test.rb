require 'test_helper'

class ServiciosHelperTest < ActionView::TestCase
end
