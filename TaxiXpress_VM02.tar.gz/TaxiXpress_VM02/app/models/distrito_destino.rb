class DistritoDestino < ActiveRecord::Base
  attr_accessible :nombredistrito
end
