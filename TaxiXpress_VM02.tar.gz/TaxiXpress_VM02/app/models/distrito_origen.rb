class DistritoOrigen < ActiveRecord::Base
  attr_accessible :nombredistrito
end
