# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
TaxiX::Application.config.secret_token = '3f987148528c1c2db581fcf52d988f47da2f1448cc6ba74ee40296e6336137d25dd35918a62645ce43404e9b94fad1f81f3ec6561e5ab6d70ca36c559882bb79'
