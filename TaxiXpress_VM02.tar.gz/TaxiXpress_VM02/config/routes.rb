TaxiX::Application.routes.draw do
  resources :servicios


  resources :clientes


  resources :precios
  
resources :distrito_origen


end
